import { g as defineEventHandler, r as readBody } from '../../../_/nitro.mjs';
import { addProducts } from './_storage.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:path';
import 'node:crypto';
import '../db/products.mjs';
import '../db/config.mjs';
import 'pg';

const batchImport_post = defineEventHandler(async (event) => {
  var _a;
  try {
    const body = await readBody(event);
    console.log("\u6279\u91CF\u5BFC\u5165\u4EA7\u54C1\u6570\u636E:", body.length, "\u6761");
    if (body.length > 0) {
      console.log("\u7B2C\u4E00\u4E2A\u4EA7\u54C1\u7684specs:", (_a = body[0]) == null ? void 0 : _a.specs);
    }
    const productsWithoutIds = body.map((product) => {
      const { id, ...rest } = product;
      return rest;
    });
    const skuMap = /* @__PURE__ */ new Map();
    productsWithoutIds.forEach((product) => {
      const sku = product.warehouseSku;
      if (!skuMap.has(sku)) {
        skuMap.set(sku, { ...product });
      } else {
        const existing = skuMap.get(sku);
        const isSameProduct = existing.productName === product.productName && existing.skuName === product.skuName && existing.productCost === product.productCost && existing.tax === product.tax && existing.domesticShipping === product.domesticShipping && existing.overseasShipping === product.overseasShipping && existing.manager === product.manager && JSON.stringify(existing.specs) === JSON.stringify(product.specs);
        if (isSameProduct) {
          if (product.temuSku) {
            const existingTemuSkus = existing.temuSku ? existing.temuSku.toString().split(",").map((s) => s.trim()).filter((s) => s) : [];
            const newTemuSku = product.temuSku.toString().trim();
            if (newTemuSku && !existingTemuSkus.includes(newTemuSku)) {
              existingTemuSkus.push(newTemuSku);
              existing.temuSku = existingTemuSkus.join(",");
            }
          }
          if (product.sheinSku) {
            const existingSheinSkus = existing.sheinSku ? existing.sheinSku.toString().split(",").map((s) => s.trim()).filter((s) => s) : [];
            const newSheinSku = product.sheinSku.toString().trim();
            if (newSheinSku && !existingSheinSkus.includes(newSheinSku)) {
              existingSheinSkus.push(newSheinSku);
              existing.sheinSku = existingSheinSkus.join(",");
            }
          }
        } else {
          console.warn(`\u4ED3\u5E93SKU ${sku} \u5B58\u5728\u591A\u6761\u4E0D\u540C\u7684\u4EA7\u54C1\u6570\u636E\uFF0C\u5DF2\u5FFD\u7565\u91CD\u590D\u9879`);
        }
      }
    });
    const mergedProducts = Array.from(skuMap.values());
    console.log(`\u539F\u59CB\u6570\u636E ${body.length} \u6761\uFF0C\u5408\u5E76\u540E ${mergedProducts.length} \u6761`);
    const newProducts = await addProducts(mergedProducts);
    return {
      code: 0,
      data: {
        success: true,
        message: `\u6210\u529F\u5BFC\u5165 ${mergedProducts.length} \u6761\u4EA7\u54C1\u6570\u636E\uFF08\u539F\u59CB ${body.length} \u6761\uFF0C\u5DF2\u81EA\u52A8\u5408\u5E76\u91CD\u590DSKU\uFF09`,
        count: mergedProducts.length,
        originalCount: body.length
      }
    };
  } catch (error) {
    console.error("\u6279\u91CF\u5BFC\u5165\u4EA7\u54C1\u5931\u8D25:", error);
    return {
      code: 500,
      message: `\u6279\u91CF\u5BFC\u5165\u5931\u8D25: ${error.message}`,
      data: null
    };
  }
});

export { batchImport_post as default };
//# sourceMappingURL=batch-import.post.mjs.map
