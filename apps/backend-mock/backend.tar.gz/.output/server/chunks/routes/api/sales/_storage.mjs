import { addDailySales as addDailySales$1, clearDailySales as clearDailySales$1, deleteDailySales as deleteDailySales$1, getDailySales as getDailySales$1 } from '../db/sales.mjs';
import '../db/config.mjs';
import 'pg';

async function getDailySales() {
  return await getDailySales$1();
}
function getClearedRanges() {
  return [];
}
function isDateCleared(date) {
  return false;
}
async function addDailySales(records) {
  await addDailySales$1(records);
}
async function deleteDailySales(date, warehouseSku) {
  await deleteDailySales$1(date, warehouseSku);
}
async function clearDailySales(startDate, endDate) {
  await clearDailySales$1(startDate, endDate);
}

export { addDailySales, clearDailySales, deleteDailySales, getClearedRanges, getDailySales, isDateCleared };
//# sourceMappingURL=_storage.mjs.map
