import { g as defineEventHandler, r as readBody } from '../../../_/nitro.mjs';
import { deleteDailySales } from './_storage.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:path';
import 'node:crypto';
import '../db/sales.mjs';
import '../db/config.mjs';
import 'pg';

const dailyDelete_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { date, warehouseSku } = body;
  if (!date) {
    return {
      code: 400,
      message: "\u65E5\u671F\u4E0D\u80FD\u4E3A\u7A7A"
    };
  }
  deleteDailySales(date, warehouseSku);
  return {
    code: 0,
    message: "\u5220\u9664\u6210\u529F"
  };
});

export { dailyDelete_post as default };
//# sourceMappingURL=daily-delete.post.mjs.map
