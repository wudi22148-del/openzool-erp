import { addProducts as addProducts$1, clearProducts as clearProducts$1, deleteProduct as deleteProduct$1, getProducts as getProducts$1, updateProduct as updateProduct$1 } from '../db/products.mjs';
import '../db/config.mjs';
import 'pg';

async function getProducts() {
  const products = await getProducts$1();
  console.log("getProducts called, current storage length:", products.length);
  return products;
}
async function setProducts(products) {
  await clearProducts$1();
  await addProducts$1(products);
  console.log("setProducts called, new storage length:", products.length);
}
async function addProducts(products) {
  const addedProducts = await addProducts$1(products);
  console.log("addProducts called, added:", products.length, "total:", addedProducts.length);
  if (addedProducts.length > 0) {
    console.log("First product in storage:", addedProducts[0]);
  }
  return addedProducts;
}
async function updateProduct(id, productData) {
  const updatedProduct = await updateProduct$1(id, productData);
  if (updatedProduct) {
    console.log("updateProduct called, id:", id, "updated product:", updatedProduct);
  }
  return updatedProduct;
}
async function deleteProduct(id) {
  await deleteProduct$1(id);
  console.log("deleteProduct called, id:", id);
}
async function clearProducts() {
  await clearProducts$1();
  console.log("clearProducts called, storage cleared");
}

export { addProducts, clearProducts, deleteProduct, getProducts, setProducts, updateProduct };
//# sourceMappingURL=_storage.mjs.map
