import { g as defineEventHandler } from '../../../_/nitro.mjs';
import { deleteProduct } from './_storage.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:path';
import 'node:crypto';
import '../db/products.mjs';
import '../db/config.mjs';
import 'pg';

const _id__delete = defineEventHandler(async (event) => {
  var _a;
  const id = (_a = event.context.params) == null ? void 0 : _a.id;
  if (id) {
    await deleteProduct(id);
  }
  return {
    code: 0,
    data: {
      success: true,
      message: "\u5220\u9664\u6210\u529F"
    }
  };
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
