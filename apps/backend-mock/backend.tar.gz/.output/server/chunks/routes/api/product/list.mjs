import { g as defineEventHandler, p as getQuery } from '../../../_/nitro.mjs';
import { getProducts } from './_storage.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:path';
import 'node:crypto';
import '../db/products.mjs';
import '../db/config.mjs';
import 'pg';

const list = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const page = Number(query.page) || 1;
  const pageSize = Number(query.pageSize) || 20;
  const keyword = query.keyword || "";
  const manager = query.manager || "";
  let allProducts = await getProducts();
  console.log("\u83B7\u53D6\u4EA7\u54C1\u5217\u8868\uFF0C\u603B\u6570:", allProducts.length);
  if (allProducts.length > 0) {
    console.log("\u7B2C\u4E00\u4E2A\u4EA7\u54C1\u7684specs:", allProducts[0].specs);
  }
  let filteredProducts = allProducts;
  if (keyword) {
    filteredProducts = filteredProducts.filter(
      (p) => p.productName.includes(keyword) || p.skuName.includes(keyword) || p.temuSku && String(p.temuSku).includes(keyword) || p.sheinSku && String(p.sheinSku).includes(keyword) || p.warehouseSku.includes(keyword)
    );
  }
  if (manager) {
    filteredProducts = filteredProducts.filter((p) => p.manager === manager);
  }
  const total = filteredProducts.length;
  const start = (page - 1) * pageSize;
  const end = start + pageSize;
  const items = filteredProducts.slice(start, end);
  return {
    code: 0,
    data: {
      items,
      total
    }
  };
});

export { list as default };
//# sourceMappingURL=list.mjs.map
