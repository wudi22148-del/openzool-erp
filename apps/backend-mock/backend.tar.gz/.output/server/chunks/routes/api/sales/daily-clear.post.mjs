import { g as defineEventHandler, r as readBody } from '../../../_/nitro.mjs';
import { clearDailySales } from './_storage.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:path';
import 'node:crypto';
import '../db/sales.mjs';
import '../db/config.mjs';
import 'pg';

const dailyClear_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { startDate, endDate } = body || {};
  await clearDailySales(startDate, endDate);
  return {
    code: 0,
    message: "\u6E05\u9664\u6210\u529F"
  };
});

export { dailyClear_post as default };
//# sourceMappingURL=daily-clear.post.mjs.map
