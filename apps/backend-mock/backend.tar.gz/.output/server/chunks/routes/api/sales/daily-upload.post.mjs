import { g as defineEventHandler, r as readBody } from '../../../_/nitro.mjs';
import { addDailySales } from './_storage.mjs';
import { getProducts } from '../product/_storage.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:path';
import 'node:crypto';
import '../db/sales.mjs';
import '../db/config.mjs';
import 'pg';
import '../db/products.mjs';

const dailyUpload_post = defineEventHandler(async (event) => {
  try {
    const body = await readBody(event);
    const salesData = body;
    if (!Array.isArray(salesData) || salesData.length === 0) {
      return {
        code: 400,
        message: "\u4E0A\u4F20\u6570\u636E\u4E0D\u80FD\u4E3A\u7A7A"
      };
    }
    console.log("\u63A5\u6536\u5230\u65E5\u9500\u6570\u636E:", salesData.length, "\u6761");
    if (salesData.length > 0) {
      console.log("\u7B2C\u4E00\u6761\u65E5\u9500\u6570\u636E:", salesData[0]);
    }
    const products = await getProducts();
    const productSkuSet = new Set(products.map((p) => p.warehouseSku));
    const uploadedSkus = new Set(salesData.map((record) => record.warehouseSku));
    const missingSkus = Array.from(uploadedSkus).filter((sku) => !productSkuSet.has(sku));
    const validData = salesData.filter((record) => productSkuSet.has(record.warehouseSku));
    const invalidData = salesData.filter((record) => !productSkuSet.has(record.warehouseSku));
    if (validData.length > 0) {
      await addDailySales(validData);
    }
    if (missingSkus.length > 0) {
      console.log("\u53D1\u73B0\u7F3A\u5931\u7684SKU:", missingSkus);
      return {
        code: 0,
        message: `\u5DF2\u6210\u529F\u4E0A\u4F20${validData.length}\u6761\u6570\u636E\u3002\u4EE5\u4E0B${missingSkus.length}\u4E2ASKU\u4E0D\u5728\u4EA7\u54C1\u5E93\u4E2D\uFF0C\u5BF9\u5E94${invalidData.length}\u6761\u6570\u636E\u672A\u4E0A\u4F20\uFF1A${missingSkus.slice(0, 10).join(", ")}${missingSkus.length > 10 ? "..." : ""}`,
        data: {
          uploadedCount: validData.length,
          skippedCount: invalidData.length,
          missingSkus,
          missingCount: missingSkus.length
        }
      };
    }
    return {
      code: 0,
      message: "\u4E0A\u4F20\u6210\u529F",
      data: {
        count: salesData.length
      }
    };
  } catch (error) {
    console.error("\u65E5\u9500\u6570\u636E\u4E0A\u4F20\u5931\u8D25:", error);
    return {
      code: 500,
      message: `\u4E0A\u4F20\u5931\u8D25: ${error.message}`,
      data: null
    };
  }
});

export { dailyUpload_post as default };
//# sourceMappingURL=daily-upload.post.mjs.map
