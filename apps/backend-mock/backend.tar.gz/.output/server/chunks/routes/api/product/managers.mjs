import { g as defineEventHandler } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:path';
import 'node:crypto';

const managers = defineEventHandler(async () => {
  return {
    code: 0,
    data: [
      { id: "1", name: "\u5F20\u4E09" },
      { id: "2", name: "\u674E\u56DB" },
      { id: "3", name: "\u738B\u4E94" }
    ]
  };
});

export { managers as default };
//# sourceMappingURL=managers.mjs.map
