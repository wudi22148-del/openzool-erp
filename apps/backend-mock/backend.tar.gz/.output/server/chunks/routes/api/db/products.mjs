import pool from './config.mjs';
import 'pg';

async function getProducts() {
  const result = await pool.query(
    "SELECT * FROM products ORDER BY id DESC"
  );
  return result.rows.map((row) => ({
    id: String(row.id),
    productName: row.product_name,
    skuName: row.sku_name,
    warehouseSku: row.warehouse_sku,
    temuSku: row.temu_sku,
    sheinSku: row.shein_sku,
    specs: {
      length: row.length,
      width: row.width,
      height: row.height,
      weight: row.weight
    },
    productCost: parseFloat(row.product_cost),
    tax: parseFloat(row.tax),
    domesticShipping: parseFloat(row.domestic_shipping),
    overseasShipping: parseFloat(row.overseas_shipping),
    manager: row.manager,
    stock: row.stock,
    imageUrl: row.image_url
  }));
}
async function addProducts(products) {
  var _a, _b, _c, _d;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const addedProducts = [];
    for (const product of products) {
      const result = await client.query(
        `INSERT INTO products (
          product_name, sku_name, warehouse_sku, temu_sku, shein_sku,
          length, width, height, weight,
          product_cost, tax, domestic_shipping, overseas_shipping,
          manager, stock, image_url
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
        ON CONFLICT (warehouse_sku) DO UPDATE SET
          product_name = EXCLUDED.product_name,
          sku_name = EXCLUDED.sku_name,
          temu_sku = EXCLUDED.temu_sku,
          shein_sku = EXCLUDED.shein_sku,
          length = EXCLUDED.length,
          width = EXCLUDED.width,
          height = EXCLUDED.height,
          weight = EXCLUDED.weight,
          product_cost = EXCLUDED.product_cost,
          tax = EXCLUDED.tax,
          domestic_shipping = EXCLUDED.domestic_shipping,
          overseas_shipping = EXCLUDED.overseas_shipping,
          manager = EXCLUDED.manager,
          stock = EXCLUDED.stock,
          image_url = EXCLUDED.image_url,
          updated_at = CURRENT_TIMESTAMP
        RETURNING *`,
        [
          product.productName,
          product.skuName,
          product.warehouseSku,
          product.temuSku || null,
          product.sheinSku || null,
          ((_a = product.specs) == null ? void 0 : _a.length) || null,
          ((_b = product.specs) == null ? void 0 : _b.width) || null,
          ((_c = product.specs) == null ? void 0 : _c.height) || null,
          ((_d = product.specs) == null ? void 0 : _d.weight) || null,
          product.productCost,
          product.tax,
          product.domesticShipping,
          product.overseasShipping,
          product.manager,
          product.stock || 0,
          product.imageUrl || null
        ]
      );
      const row = result.rows[0];
      addedProducts.push({
        id: String(row.id),
        productName: row.product_name,
        skuName: row.sku_name,
        warehouseSku: row.warehouse_sku,
        temuSku: row.temu_sku,
        sheinSku: row.shein_sku,
        specs: {
          length: row.length,
          width: row.width,
          height: row.height,
          weight: row.weight
        },
        productCost: parseFloat(row.product_cost),
        tax: parseFloat(row.tax),
        domesticShipping: parseFloat(row.domestic_shipping),
        overseasShipping: parseFloat(row.overseas_shipping),
        manager: row.manager,
        stock: row.stock,
        imageUrl: row.image_url
      });
    }
    await client.query("COMMIT");
    return addedProducts;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}
async function updateProduct(id, productData) {
  var _a, _b, _c, _d;
  const result = await pool.query(
    `UPDATE products SET
      product_name = COALESCE($1, product_name),
      sku_name = COALESCE($2, sku_name),
      warehouse_sku = COALESCE($3, warehouse_sku),
      temu_sku = COALESCE($4, temu_sku),
      shein_sku = COALESCE($5, shein_sku),
      length = COALESCE($6, length),
      width = COALESCE($7, width),
      height = COALESCE($8, height),
      weight = COALESCE($9, weight),
      product_cost = COALESCE($10, product_cost),
      tax = COALESCE($11, tax),
      domestic_shipping = COALESCE($12, domestic_shipping),
      overseas_shipping = COALESCE($13, overseas_shipping),
      manager = COALESCE($14, manager),
      stock = COALESCE($15, stock),
      image_url = COALESCE($16, image_url),
      updated_at = CURRENT_TIMESTAMP
    WHERE id = $17
    RETURNING *`,
    [
      productData.productName,
      productData.skuName,
      productData.warehouseSku,
      productData.temuSku,
      productData.sheinSku,
      (_a = productData.specs) == null ? void 0 : _a.length,
      (_b = productData.specs) == null ? void 0 : _b.width,
      (_c = productData.specs) == null ? void 0 : _c.height,
      (_d = productData.specs) == null ? void 0 : _d.weight,
      productData.productCost,
      productData.tax,
      productData.domesticShipping,
      productData.overseasShipping,
      productData.manager,
      productData.stock,
      productData.imageUrl,
      id
    ]
  );
  if (result.rows.length === 0) return null;
  const row = result.rows[0];
  return {
    id: String(row.id),
    productName: row.product_name,
    skuName: row.sku_name,
    warehouseSku: row.warehouse_sku,
    temuSku: row.temu_sku,
    sheinSku: row.shein_sku,
    specs: {
      length: row.length,
      width: row.width,
      height: row.height,
      weight: row.weight
    },
    productCost: parseFloat(row.product_cost),
    tax: parseFloat(row.tax),
    domesticShipping: parseFloat(row.domestic_shipping),
    overseasShipping: parseFloat(row.overseas_shipping),
    manager: row.manager,
    stock: row.stock,
    imageUrl: row.image_url
  };
}
async function deleteProduct(id) {
  await pool.query("DELETE FROM products WHERE id = $1", [id]);
}
async function clearProducts() {
  await pool.query("TRUNCATE TABLE products RESTART IDENTITY CASCADE");
}

export { addProducts, clearProducts, deleteProduct, getProducts, updateProduct };
//# sourceMappingURL=products.mjs.map
