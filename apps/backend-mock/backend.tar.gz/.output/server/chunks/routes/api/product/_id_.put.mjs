import { g as defineEventHandler, o as getRouterParam, r as readBody } from '../../../_/nitro.mjs';
import { updateProduct } from './_storage.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:path';
import 'node:crypto';
import '../db/products.mjs';
import '../db/config.mjs';
import 'pg';

const _id__put = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  const body = await readBody(event);
  console.log("\u66F4\u65B0\u4EA7\u54C1:", id, body);
  console.log("\u66F4\u65B0\u4EA7\u54C1specs:", body.specs);
  const updatedProduct = await updateProduct(id, body);
  if (!updatedProduct) {
    return {
      code: 404,
      message: "\u4EA7\u54C1\u4E0D\u5B58\u5728"
    };
  }
  console.log("\u66F4\u65B0\u540E\u7684\u4EA7\u54C1:", updatedProduct);
  console.log("\u66F4\u65B0\u540E\u7684\u4EA7\u54C1specs:", updatedProduct.specs);
  return {
    code: 0,
    data: updatedProduct
  };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
