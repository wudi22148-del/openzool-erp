import pool from './config.mjs';
import 'pg';

async function getDailySales() {
  const result = await pool.query(
    "SELECT * FROM daily_sales ORDER BY date DESC, warehouse_sku"
  );
  return result.rows.map((row) => ({
    date: row.date.toISOString().split("T")[0],
    warehouseSku: row.warehouse_sku,
    salesQuantity: parseFloat(row.sales_quantity),
    orderNumber: row.order_number
  }));
}
async function addDailySales(records) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    for (const record of records) {
      await client.query(
        `INSERT INTO daily_sales (date, warehouse_sku, sales_quantity, order_number)
         VALUES ($1, $2, $3, $4)`,
        [
          record.date,
          record.warehouseSku,
          record.salesQuantity,
          record.orderNumber || null
        ]
      );
    }
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}
async function deleteDailySales(date, warehouseSku) {
  if (warehouseSku) {
    await pool.query(
      "DELETE FROM daily_sales WHERE date = $1 AND warehouse_sku = $2",
      [date, warehouseSku]
    );
  } else {
    await pool.query("DELETE FROM daily_sales WHERE date = $1", [date]);
  }
}
async function clearDailySales(startDate, endDate) {
  if (startDate && endDate) {
    await pool.query(
      "DELETE FROM daily_sales WHERE date >= $1 AND date <= $2",
      [startDate, endDate]
    );
  } else {
    await pool.query("TRUNCATE TABLE daily_sales RESTART IDENTITY");
  }
}

export { addDailySales, clearDailySales, deleteDailySales, getDailySales };
//# sourceMappingURL=sales.mjs.map
