import { Pool } from 'pg';

const pool = new Pool({
  host: "localhost",
  port: 5432,
  database: "openzool_erp",
  user: "erp_user",
  password: "erp_password_2026",
  max: 20,
  idleTimeoutMillis: 3e4,
  connectionTimeoutMillis: 2e3
});
pool.on("connect", () => {
  console.log("\u6570\u636E\u5E93\u8FDE\u63A5\u6210\u529F");
});
pool.on("error", (err) => {
  console.error("\u6570\u636E\u5E93\u8FDE\u63A5\u9519\u8BEF:", err);
});

export { pool as default };
//# sourceMappingURL=config.mjs.map
