import { g as defineEventHandler, p as getQuery } from '../../../_/nitro.mjs';
import { getProducts } from '../product/_storage.mjs';
import { getDailySales } from './_storage.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:path';
import 'node:crypto';
import '../db/products.mjs';
import '../db/config.mjs';
import 'pg';
import '../db/sales.mjs';

async function generateMockSalesData(products, startDate, endDate, mode = "quantity") {
  const start = new Date(startDate);
  const end = new Date(endDate);
  const days = Math.ceil((end.getTime() - start.getTime()) / (1e3 * 60 * 60 * 24)) + 1;
  const uploadedSales = await getDailySales();
  console.log("\u7EDF\u8BA1\u67E5\u8BE2\u53C2\u6570:", { startDate, endDate, mode, uploadedSalesCount: uploadedSales.length });
  if (uploadedSales.length > 0) {
    console.log("\u7B2C\u4E00\u6761\u65E5\u9500\u6570\u636E:", uploadedSales[0]);
  }
  console.log("\u4EA7\u54C1\u6570\u91CF:", products.length);
  if (products.length > 0) {
    console.log("\u7B2C\u4E00\u4E2A\u4EA7\u54C1:", products[0]);
  }
  const salesMap = /* @__PURE__ */ new Map();
  const ordersMap = /* @__PURE__ */ new Map();
  if (mode === "orders") {
    const orderTotals = /* @__PURE__ */ new Map();
    uploadedSales.forEach((record) => {
      if (record.orderNumber) {
        const orderKey = `${record.date}_${record.orderNumber}`;
        orderTotals.set(orderKey, (orderTotals.get(orderKey) || 0) + record.salesQuantity);
      }
    });
    uploadedSales.forEach((record) => {
      const key = `${record.date}_${record.warehouseSku}`;
      if (record.orderNumber) {
        const orderKey = `${record.date}_${record.orderNumber}`;
        const orderTotal = orderTotals.get(orderKey) || record.salesQuantity;
        const orderCount = record.salesQuantity / orderTotal;
        ordersMap.set(key, (ordersMap.get(key) || 0) + orderCount);
      } else {
        ordersMap.set(key, (ordersMap.get(key) || 0) + 1);
      }
    });
  } else {
    uploadedSales.forEach((record) => {
      const key = `${record.date}_${record.warehouseSku}`;
      salesMap.set(key, (salesMap.get(key) || 0) + record.salesQuantity);
    });
  }
  const salesData = products.map((product, index) => {
    const dailySales = {};
    const trendData = [];
    let totalSales = 0;
    for (let i = 0; i < days; i++) {
      const currentDate = new Date(start);
      currentDate.setDate(start.getDate() + i);
      const dateStr = currentDate.toISOString().split("T")[0];
      const field = `date_${dateStr.replace(/-/g, "_")}`;
      const key = `${dateStr}_${product.warehouseSku}`;
      let sales = 0;
      if (mode === "orders") {
        if (ordersMap.has(key)) {
          sales = ordersMap.get(key);
        }
      } else {
        if (salesMap.has(key)) {
          sales = salesMap.get(key);
        }
      }
      dailySales[field] = sales;
      trendData.push(sales);
      totalSales += sales;
    }
    const avgDailySales = totalSales / days;
    return {
      id: product.id,
      manager: product.manager,
      productName: product.productName,
      skuName: product.skuName,
      warehouseSku: product.warehouseSku,
      totalSales,
      avgDailySales: Number(avgDailySales.toFixed(1)),
      trendData,
      ...dailySales
    };
  });
  return salesData;
}
const statistics = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const page = Number(query.page) || 1;
  const pageSize = Number(query.pageSize) || 20;
  const keyword = query.keyword || "";
  const manager = query.manager || "";
  const startDate = query.startDate;
  const endDate = query.endDate;
  const mode = query.mode || "quantity";
  if (!startDate || !endDate) {
    return {
      code: 400,
      message: "\u8BF7\u63D0\u4F9B\u5F00\u59CB\u65E5\u671F\u548C\u7ED3\u675F\u65E5\u671F"
    };
  }
  const allProducts = await getProducts();
  if (allProducts.length === 0) {
    return {
      code: 0,
      data: {
        items: [],
        total: 0
      }
    };
  }
  let salesData = await generateMockSalesData(allProducts, startDate, endDate, mode);
  if (keyword) {
    salesData = salesData.filter(
      (item) => item.productName.includes(keyword) || item.skuName.includes(keyword) || item.warehouseSku.includes(keyword)
    );
  }
  if (manager) {
    salesData = salesData.filter((item) => item.manager === manager);
  }
  salesData = salesData.filter((item) => item.totalSales > 0);
  const start = new Date(startDate);
  const end = new Date(endDate);
  const days = Math.ceil((end.getTime() - start.getTime()) / (1e3 * 60 * 60 * 24)) + 1;
  const validDates = [];
  for (let i = 0; i < days; i++) {
    const currentDate = new Date(start);
    currentDate.setDate(start.getDate() + i);
    const dateStr = currentDate.toISOString().split("T")[0];
    const field = `date_${dateStr.replace(/-/g, "_")}`;
    const hasData = salesData.some((item) => item[field] > 0);
    if (hasData) {
      validDates.push(field);
    }
  }
  salesData = salesData.map((item) => {
    const filteredItem = {
      id: item.id,
      manager: item.manager,
      productName: item.productName,
      skuName: item.skuName,
      warehouseSku: item.warehouseSku,
      totalSales: item.totalSales,
      avgDailySales: item.avgDailySales,
      trendData: item.trendData
    };
    validDates.forEach((dateField) => {
      filteredItem[dateField] = item[dateField];
    });
    return filteredItem;
  });
  const total = salesData.length;
  const start_idx = (page - 1) * pageSize;
  const end_idx = start_idx + pageSize;
  const items = salesData.slice(start_idx, end_idx);
  return {
    code: 0,
    data: {
      items,
      total
    }
  };
});

export { statistics as default };
//# sourceMappingURL=statistics.mjs.map
