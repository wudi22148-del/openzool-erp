import{aK as a}from"./bootstrap-B2r95Nb9.js";import{ah as o,aD as t}from"../jse/index-index-Cm_Ul_Lv.js";const s=(()=>{const e=t(!1);return o(()=>{e.value=a()}),e});export{s as u};
