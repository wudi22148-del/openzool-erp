import{_ as o}from"./password-setting.vue_vue_type_script_setup_true_lang-Bs3Oq-hB.js";import"./bootstrap-p2DASM_U.js";import"../jse/index-index-CfKxp2un.js";export{o as default};
