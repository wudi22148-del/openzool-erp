import{L as a,X as i}from"../jse/index-index-h59owaWl.js";function m(e,c,r){const f=a(e());return i(c,(o,s)=>{r?r(o,s)&&(f.value=e()):f.value=e()}),f}export{m as u};
