import{aK as a}from"./bootstrap-fNAd-X29.js";import{ah as o,aD as t}from"../jse/index-index-h59owaWl.js";const s=(()=>{const e=t(!1);return o(()=>{e.value=a()}),e});export{s as u};
