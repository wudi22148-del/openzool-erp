import{aK as a}from"./bootstrap-BdcVehUQ.js";import{ah as o,aD as t}from"../jse/index-index-DE1c3R9q.js";const s=(()=>{const e=t(!1);return o(()=>{e.value=a()}),e});export{s as u};
