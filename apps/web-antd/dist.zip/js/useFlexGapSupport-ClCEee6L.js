import{aK as a}from"./bootstrap-HQGK9yDD.js";import{ah as o,aD as t}from"../jse/index-index-Cl7-yY6p.js";const s=(()=>{const e=t(!1);return o(()=>{e.value=a()}),e});export{s as u};
