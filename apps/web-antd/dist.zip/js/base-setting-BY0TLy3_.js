import{_ as o}from"./base-setting.vue_vue_type_script_setup_true_lang-CAh3RkYh.js";import"./bootstrap-HQGK9yDD.js";import"../jse/index-index-Cl7-yY6p.js";export{o as default};
