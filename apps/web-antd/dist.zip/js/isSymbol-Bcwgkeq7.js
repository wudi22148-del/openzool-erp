import{af as s,aC as t}from"./bootstrap-p2DASM_U.js";var a="[object Symbol]";function e(o){return typeof o=="symbol"||s(o)&&t(o)==a}export{e as i};
