import{aK as a}from"./bootstrap-CINw2Qk3.js";import{ah as o,aD as t}from"../jse/index-index-CjcHs02-.js";const s=(()=>{const e=t(!1);return o(()=>{e.value=a()}),e});export{s as u};
