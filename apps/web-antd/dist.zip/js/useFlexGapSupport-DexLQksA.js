import{aK as a}from"./bootstrap-p2DASM_U.js";import{ah as o,aD as t}from"../jse/index-index-CfKxp2un.js";const s=(()=>{const e=t(!1);return o(()=>{e.value=a()}),e});export{s as u};
