import{_ as o}from"./base-setting.vue_vue_type_script_setup_true_lang-COHiHnTm.js";import"./bootstrap-BdcVehUQ.js";import"../jse/index-index-DE1c3R9q.js";export{o as default};
