const a="Update Password",s="Update Basic Profile",e={updatePassword:a,updateBasicProfile:s};export{e as default,s as updateBasicProfile,a as updatePassword};
