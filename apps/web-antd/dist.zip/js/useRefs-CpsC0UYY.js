import{bM as o,L as r}from"../jse/index-index-Cl7-yY6p.js";const f=()=>{const e=r(new Map),s=t=>a=>{e.value.set(t,a)};return o(()=>{e.value=new Map}),[s,e]};export{f as u};
