const o="更新密码",s="更新基本信息",t={updatePassword:o,updateBasicProfile:s};export{t as default,s as updateBasicProfile,o as updatePassword};
