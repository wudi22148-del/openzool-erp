import{_ as o}from"./password-setting.vue_vue_type_script_setup_true_lang-CVEOyQ_E.js";import"./bootstrap-BdcVehUQ.js";import"../jse/index-index-DE1c3R9q.js";export{o as default};
