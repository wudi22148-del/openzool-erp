import{_ as o}from"./base-setting.vue_vue_type_script_setup_true_lang-DDtExGK4.js";import"./bootstrap-p2DASM_U.js";import"../jse/index-index-CfKxp2un.js";export{o as default};
