import{_ as o}from"./base-setting.vue_vue_type_script_setup_true_lang-DkwIJF77.js";import"./bootstrap-B2r95Nb9.js";import"../jse/index-index-Cm_Ul_Lv.js";export{o as default};
